//
//  ViewController.swift
//  Stopwatch
//
//  Created by Puia Robert on 06/10/2018.
//  Copyright © 2018 Omaldoks. All rights reserved.
//

import UIKit


class StopWatchViewController: UIViewController {
    
    
    //MARK: - Outlets
    @IBOutlet private weak var startButton: UIButton!
    @IBOutlet private weak var lapButton: UIButton!
    @IBOutlet private weak var timeLabel: UILabel!
    @IBOutlet private weak var lapsTableView: UITableView!
    
    var timer: Timer!
    var minutes = 0
    var seconds = 0
    var fractions = 0
    var lapArray: [String]? = []// to track the laps
    var addLap = false
    var counterString = ""
    var isStarted = false
    
    
    
    //MARK: - Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        makeStatusBarWhite()
        configureInterface()
        
        timeLabel.text  = "00:00.00"
        
        
    }
    
    
    
    
    
    
    func configureInterface() {
        startButton.layer.cornerRadius = startButton.frame.size.height/2
        lapButton.layer.cornerRadius = startButton.frame.size.height/2
    }
    
    
    @objc func timeDidIncrease() {
        
        fractions += 1
        if fractions == 100 {
            seconds += 1
            fractions = 0
        }
        if seconds == 60 {
            minutes += 1
            seconds = 0
        }
        
        let fractionsString = fractions > 9 ? "\(fractions)" : "0\(fractions)"
        let secondsString = seconds > 9 ? "\(seconds)" : "0\(seconds)"
        let minutesString = minutes > 9 ? "\(minutes)" : "0\(minutes)"
        
        
        counterString = "\(minutesString):\(secondsString).\(fractionsString)"
        timeLabel.text = counterString
        
        
        
    }
    
    
    func configureAndStartTimer() {
        timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(timeDidIncrease) , userInfo: nil, repeats: true)
        
        RunLoop.current.add(timer, forMode: RunLoop.Mode.common) //timer will not be affected by UI interaction
    }
    
    
    
    
    //MARK: - Actions
    @IBAction func didTapLap(_ sender: Any) {
        
        if isStarted {
            lapArray?.insert(timeLabel.text!, at:0)
            
            
        }else {
            timeLabel.text = "00:00.00"
            fractions = 0
            minutes = 0
            seconds = 0
            timer.invalidate()
            lapArray?.removeAll()
            resetStartButton()
            lapButton.setTitle("Lap", for: .normal)
            lapButton.isUserInteractionEnabled = false
            lapButton.alpha = 0.3
            
        }
        lapsTableView.reloadData()
    }
    
    func resetStartButton() {
        startButton.setTitle("Start", for: .normal)
        startButton.backgroundColor = UIColor.green
        
    }
    
    @IBAction func didTapStart(_ sender: Any) {
        if !isStarted {
            configureAndStartTimer()
            isStarted = true
            startButton.setTitle("Stop", for: .normal)
            startButton.backgroundColor = UIColor.red
            lapButton.setTitle("Lap", for: .normal)
            addLap = true
        } else {
            timer.invalidate()
            isStarted = false
            resetStartButton()
            lapButton.setTitle("Reset", for: .normal)
            addLap = false
        }
        lapButton.isUserInteractionEnabled = true
        lapButton.alpha = 1
    }
    
}


extension StopWatchViewController:
UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lapArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! LapsTableViewCell
        let currentLap = lapArray?[indexPath.row]
        cell.lapName = "Lap \((lapArray?.count ?? 0) - indexPath.row)"
        cell.lapTime = currentLap
        cell.selectionStyle = .none
        return cell
    }
    
    //MARK: Table View Datasource methods
}

extension StopWatchViewController:
UITableViewDelegate{
    //MARK: Table View Delegate methods
}

