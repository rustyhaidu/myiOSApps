//
//  ViewController.swift
//  LearnToApp
//
//  Created by Puia Robert on 22/09/2018.
//  Copyright © 2018 Omaldoks. All rights reserved.
//



import UIKit
import QuartzCore



enum TimeOfDay: String {
    case Dimineata = "Dimineata"
    case Pranz = "Pranz"
    case Seara = "Seara"
}

class ViewController: UIViewController {
    @IBOutlet weak var timeOfDayLabel: UILabel!
    @IBOutlet weak var sunImage: UIImageView!
    @IBOutlet weak var appBackground: UIImageView!
    @IBOutlet var popupView: UIView!
    @IBOutlet weak var visualEffectView: UIVisualEffectView!
    
    
    @IBAction func dismissPopup(_ sender: UIButton) {
    }
    
    var timeOfDay = TimeOfDay.Dimineata
    var effect:UIVisualEffect!
    
    
    
    //var timeOfDay = "Dimineata"

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

//
}
    
//                            func animateIn() {
//                                self.view.addSubview(popupView)
//                                popupView.center = self.view.center
//                                popupView.transform =  CGAffineTransform.init(scaleX: 1.3, y: 1.3)
//                                popupView.alpha = 0
//
//                                UIView.animate(withDuration: 0.4) {
//                                    self.visualEffectView.effect = self.effect
//                                    self.popupView.alpha = 1
//                                    self.popupView.transform = CGAffineTransform.identity
//
//                                }
//
//
//                            }
    
    
    
    
    @IBAction func didTapNext(_ sender: Any) {


        sunImage.translatesAutoresizingMaskIntoConstraints = true
        view.addSubview(sunImage)

        switch timeOfDay {
                    case .Dimineata:
                        timeOfDay = .Pranz
                        sunImage.image = UIImage(named: "LunchSun")
                        self.appBackground.alpha = 1
                        
                        
                        let initialX: CGFloat = -40
                        let sunImageWidth: CGFloat = 60
                        sunImage.frame = CGRect(x: initialX,
                                                 y: view.frame.height / 4.0 - 5,
                                                 width: 100,
                                                 height: 100)

                        let circularPath = UIBezierPath(arcCenter: view.center,
                                                        radius: view.frame.width / 2 - initialX - sunImageWidth / 2,
                                                        startAngle: -.pi,
                                                        endAngle: -1.57,
                                                        clockwise: true)
                        let animation = CAKeyframeAnimation(keyPath: #keyPath(CALayer.position))
                        animation.duration = 2  // In seconds
                        animation.repeatCount = 1 //At maximum it could be MAXFLOAT if you want the animation to seem to loop forever
                        animation.path = circularPath.cgPath
                        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)  //Optional
                        sunImage.layer.add(animation, forKey: "myAnimation")
                        sunImage.frame.origin.x = circularPath.cgPath.currentPoint.x - sunImage.frame.width / 2
                        sunImage.frame.origin.y = circularPath.cgPath.currentPoint.y - sunImage.frame.height / 2

                    case .Pranz:
                        timeOfDay = .Seara
                        sunImage.image = UIImage(named: "NightSun")
                            self.appBackground.alpha = 0.5
                        
                        let initialX: CGFloat = -40
                        let imageViewWidth: CGFloat = 60
                        let circularPath = UIBezierPath(arcCenter: view.center,
                                                        radius: view.frame.width / 2 - initialX - imageViewWidth / 2,
                                                        startAngle: -1.57,
                                                        endAngle: -0.3,
                                                        clockwise: true)
                        let animation = CAKeyframeAnimation(keyPath: #keyPath(CALayer.position))
                        animation.duration = 2  // In seconds
                        animation.repeatCount = 1 //At maximum it could be MAXFLOAT if you want the animation to seem to loop forever
                        animation.path = circularPath.cgPath
                        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)  //Optional
                        sunImage.layer.add(animation, forKey: "myAnimation")
                        sunImage.frame.origin.x = circularPath.cgPath.currentPoint.x - sunImage.frame.width / 2
                        sunImage.frame.origin.y = circularPath.cgPath.currentPoint.y - sunImage.frame.height / 2




                    default:
                        timeOfDay = .Dimineata
                        sunImage.image = UIImage(named: "MorningSun")

                        let initialX: CGFloat = -40
                        let imageViewWidth: CGFloat = 60
                        let circularPath = UIBezierPath(arcCenter: view.center,
                                                        radius: view.frame.width / 2 - initialX - imageViewWidth / 2,
                                                        startAngle: -0.3,
                                                        endAngle: -.pi,
                                                        clockwise: true)
                        let animation = CAKeyframeAnimation(keyPath: #keyPath(CALayer.position))
                        animation.duration = 2  // In seconds
                        animation.repeatCount = 1 //At maximum it could be MAXFLOAT if you want the animation to seem to loop forever
                        animation.path = circularPath.cgPath
                        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)  //Optional
                        sunImage.layer.add(animation, forKey: "myAnimation")
                        sunImage.frame.origin.x = circularPath.cgPath.currentPoint.x - sunImage.frame.width / 2
                        sunImage.frame.origin.y = circularPath.cgPath.currentPoint.y - sunImage.frame.height / 2
                        self.appBackground.alpha = 1
                        
                        let alert = UIAlertController(title: "Success",
                                                      message: "A mai trecut o zi",
                                                      preferredStyle: .alert)
                        let okAction = UIAlertAction(title: "Ok", style: .cancel) { (action) in
                            self.visualEffectView.isHidden = true
                            
                        }
                        alert.addAction(okAction)
                        present(alert,animated:true)
            
                        visualEffectView.isHidden = false
                        

            
            
            
                        }

                    timeOfDayLabel.text = timeOfDay.rawValue.uppercased()

}
}

        
        
        

        






////  switch +  case option  ////


//    @IBAction func didTapNext(_ sender: Any) {
//        switch timeOfDay {
//        case .Dimineata:
//            timeOfDay = .Pranz
//            sunImage.image = UIImage(named: "LunchSun")
//            UIView.animate(withDuration: 1) {
//                self.sunImage.frame = CGRect(x: self.view.frame.origin.x-50, y: 166, width: 100, height: 100)
//            }
//        case .Pranz:
//            timeOfDay = .Seara
//            sunImage.image = UIImage(named: "NightSun")
//            UIView.animate(withDuration: 1) {
//                self.sunImage.frame = CGRect(x: self.view.frame.width-50, y: 166, width: 100, height: 100)
//                self.appBackground.alpha = 0.5
//            }
//        default:
//            timeOfDay = .Dimineata
//            sunImage.image = UIImage(named: "NightSun")
//            UIView.animate(withDuration: 1) {
//                self.sunImage.frame = CGRect(x: self.view.frame.origin.x-50, y: 166, width: 100, height: 100)
//                self.appBackground.alpha = 1
//
//            }
//        }
//        timeOfDayLabel.text = timeOfDay.rawValue.uppercased()
//    }

    
    
    





/// if else if option //

//class ViewController: UIViewController {
//    @IBOutlet weak var timeOfDayLabel: UILabel!
//    @IBOutlet weak var sunImage: UIImageView!
//
//    var timeOfDay = "Dimineata"
//
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//    }
//
//    @IBAction func didTapNext(_ sender: Any) {
//        if timeOfDayLabel.text == "Dimineata" {
//        timeOfDayLabel.text = "Pranz"
//        timeOfDay = "Pranz"
//        sunImage.image = UIImage(named: "LunchSun")
//            UIView.animate(withDuration: 1) {
//                self.sunImage.frame = CGRect(x: self.view.center.x-50, y: 120, width: 100,
//                                             height: 100)
//            }
//
//
//
//    }  else if timeOfDayLabel.text == "Pranz" {
//        timeOfDayLabel.text = "Seara"
//        timeOfDay = "Seara"
//        sunImage.image = UIImage(named: "NightSun")
//            UIView.animate(withDuration: 1) {
//                self.sunImage.frame = CGRect(x: self.view.center.x-50, y: 166, width: 100,
//                                             height: 100)
//            }
//
//        } else {
//        timeOfDayLabel.text = "Seara"
//        timeOfDay = "Seara"
//        sunImage.image = UIImage(named: "NightSun")
//}
//}
//
//
//
//
//
//}




