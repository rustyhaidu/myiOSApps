//
//  WelcomeScreenViewController.swift
//  Stopwatch
//
//  Created by Zaharia Madalin-Constantin on 06/10/2018.
//  Copyright © 2018 Zaharia_Madalin_Constantin. All rights reserved.
//

import UIKit

class WelcomeScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("DidLoad")
       

     }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("WillAppear")
        
        // MARK: -Black status bar
        makeStatusBarBlack()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("DidAppear")
        
        
    }

    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("willDisappear")
    }
    

   

}
