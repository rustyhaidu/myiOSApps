//
//  ViewController.swift
//  Stopwatch
//
//  Created by Zaharia Madalin-Constantin on 06/10/2018.
//  Copyright © 2018 Zaharia_Madalin_Constantin. All rights reserved.
//

import UIKit

class StopWatchViewController: UIViewController {
    
//    // metode 2 la functia din extensions
    
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .lightContent   //  e doar getter
//    }
    
    // MARK: - Outlets
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var lapButton: UIButton!
    @IBOutlet weak var startButton: UIButton!
    
    @IBOutlet weak var lapsTableView: UITableView!
    
    
    var timer : Timer!  // instantiat Timer()
    var counter = 0.0
    
    var isStarted = false
    
    // MARK: - Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
       configureInterface()
    }
    
    private func configureInterface(){
        lapButton.layer.cornerRadius = lapButton.frame.size.width/2
        startButton.layer.cornerRadius = startButton.frame.size.width/2
     }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        makeStatusBarWhite()
    }
    func configureAndStartTimer(){
        timer =  Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(timeDidIncrease), userInfo: nil, repeats: true)

    }
    
    // MARK: - Actions
    @IBAction func didTapStart(_ sender: Any) {
        if !isStarted {
            configureAndStartTimer()
            isStarted = true
            startButton.setTitle("Stop", for: .normal)
            startButton.backgroundColor = UIColor.red
            startButton.alpha = 0.7
            lapButton.alpha = 1
            lapButton.isUserInteractionEnabled = true
            lapButton.setTitle("Lap", for: .normal)
        }
        else {
            timer.invalidate()
            isStarted = false
            startButton.setTitle("Start", for: .normal)
            startButton.backgroundColor = UIColor.green
            startButton.alpha = 0.7
            lapButton.setTitle("Reset", for: .normal)
            lapButton.alpha = 0.7
        }
    }
    
    
    @IBAction func didTapLap(_ sender: Any) {
        if lapButton.currentTitle == "Reset" {
            counter = 0
            timeLabel.text = String(format: "%02d:%02d,%02d", counter, counter, counter)
        }
        
        else { // lapButton.currentTitle == "Lap"
            //  salvez timpul in celula(row) table view-ului
            //TODO: implementeaza tableView
            print("Lap")
        }
        
    }
    
    
    
    @objc func timeDidIncrease() {  // dynamic dispatch
        counter += 0.1
        
        //timeLabel.text = "\(round(counter*10)/10)"  // la fel pot sa pun: String(counter)
        
        //timeLabel.text = String(format: "%02d:%02d,%d", counter / 60, counter % 60, counter * 10 % 10)
        // % nu mai este disponibil in Swift 3-4 si Apple recomanda sa folosim truncatingRemainder
        
        let minutes = Int(counter.truncatingRemainder(dividingBy: 3600) / 60)
        let seconds = Int(counter.truncatingRemainder(dividingBy: 60))
        let tensOfSeconds = Int(counter.truncatingRemainder(dividingBy: 10) * 10)
            
        timeLabel.text = String(format: "%02d:%02d,%02d", minutes, seconds, tensOfSeconds)
        

        // round(counter) = afiseaza la secunda
        // round(counter*10)/10 = afiseaza si la milisecunda
        //print("time fired")
    }
}

